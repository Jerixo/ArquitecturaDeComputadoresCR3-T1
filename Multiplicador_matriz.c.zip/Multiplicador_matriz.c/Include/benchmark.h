#ifndef BENCHMARK_H
#define BENCHMARK_H

#include <time.h>

double elapsed_time(clock_t start, clock_t end);

#endif
