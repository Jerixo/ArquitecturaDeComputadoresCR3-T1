#ifndef NAIVE_MULTIPLY_H
#define NAIVE_MULTIPLY_H

void naive_multiply(double** A, double** B, double** C, int n);

#endif
